package controllers
import models._

import javax.inject._
import play.api._
import play.api.mvc._
import scala.collection.mutable.ListBuffer
import play.api.data._
import play.api.data.Forms._
import play.api.i18n._

/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class TodoController @Inject()(val controllerComponents: ControllerComponents) extends BaseController with I18nSupport {
    

    val form = Form("Todo" -> nonEmptyText) 

    val todo = TaskModel.tasks

    def tasks = Action { implicit request =>
        Ok(views.html.todo(form, todo.toList))
    }
   

    def addTask() = Action { implicit request =>
        form.bindFromRequest().fold(
            formWithErrors => {
                BadRequest("Something went wrong")
            },
            task => {
                /* binding success, you get the actual value. */
                TaskModel.create(task)
                Ok(views.html.todo(form, todo.toList))
            }
)
    }
    
    def deleteTask(id: Int) = TODO
}
