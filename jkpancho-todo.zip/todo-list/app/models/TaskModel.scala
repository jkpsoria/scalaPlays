package models

import scala.collection.mutable.ListBuffer

case class TaskModel(id: Long, label: String)

object TaskModel {

    val tasks = ListBuffer("eat", "code", "cry", "sleep")


    
    def create(task: String) = tasks += task
    
    def delete(id: Int) = tasks -= ???
  
}