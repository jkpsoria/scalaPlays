package models

import scala.collection.mutable.ListBuffer
import java.util.UUID
import java.awt.Image



case class ImageModel(id: UUID, name: String, caption: String, commentList: List[ImageCommentModel])
case class ImageCommentModel(id: UUID, comment: String)

object ImageModel {
    val images: ListBuffer[ImageModel] = ListBuffer()

    def add(image: ImageModel) = images += image
}

object ImageCommentModel{
    
    val comments: ListBuffer[ImageCommentModel] = ListBuffer()

    def addComment(comment: ImageCommentModel) = comments += comment
    println("commentad")
}