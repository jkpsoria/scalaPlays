package controllers

import javax.inject._
import play.api._
import play.api.mvc._
import java.nio.file.Paths
import models._
import java.util.UUID
import play.api.data.Forms._
import play.api.data.Form
import org.checkerframework.checker.i18nformatter.qual.I18nFormat
import play.api.i18n.I18nSupport

/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */


@Singleton
class HomeController @Inject()(val controllerComponents: ControllerComponents) extends BaseController with I18nSupport {

  val imageModel = ImageModel
  val imageList = imageModel.images

  val imageCommentModel = ImageCommentModel
  val imageCommentList = imageCommentModel.comments

    def imageInfo = Form(
      mapping(
        "id" -> default(uuid, UUID.randomUUID()),
        "name" -> ignored(""),
        "caption"  -> nonEmptyText,
        "comments" -> list(imageComment.mapping)
    )(imageModel.apply)(imageModel.unapply)
  )

    def imageComment = Form(
      mapping (
        "id" -> default(uuid, UUID.randomUUID()),
        "comments" -> text
      )(imageCommentModel.apply)(imageCommentModel.unapply)
    )

  def index() = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.index(imageList.toList, imageCommentList.toList, imageInfo, imageComment))
  }

  def upload = Action(parse.multipartFormData) { implicit request =>

    imageInfo.bindFromRequest().fold(
      formWithErrors => {
        BadRequest("something went wrong")
      },
      image => {
        request.body
        .file("picture")
        .map { picture =>
          val filename    = Paths.get(picture.filename).getFileName
          val fileSize    = picture.fileSize
          val contentType = picture.contentType
        
          picture.ref.copyTo(Paths.get(s"public/images/$filename"), replace = true)
          imageModel.add(ImageModel(UUID.randomUUID, s"/images/$filename", image.caption, image.commentList))
          Redirect(routes.HomeController.index())
        }
        .getOrElse {
          Redirect(routes.HomeController.index()).flashing("error" -> "Missing file")
        }
      }
    )
  }

  def comment(ids: UUID) = Action { implicit request =>
    imageComment.bindFromRequest().fold(
      formWithErrors => {
        BadRequest("Something went wrong")
      },
      comm => {
        imageCommentModel.addComment(ImageCommentModel(ids, comm.comment))
        Redirect(routes.HomeController.index())
      }
    )
  }

}
