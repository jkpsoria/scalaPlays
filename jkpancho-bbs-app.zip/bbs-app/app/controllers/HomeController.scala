package controllers

import javax.inject._
import play.api._
import play.api.mvc._
import play.api.i18n.I18nSupport
import models._
import java.util.UUID
import play.api.data.Forms._
import play.api.data.Form
import java.awt.Image
import views.html.defaultpages.badRequest
import org.checkerframework.checker.i18nformatter.qual.I18nFormat
import java.nio.file.Paths

/**
 * This controller creates an `Action` to handle HTTP requests to the
 * application's home page.
 */
@Singleton
class HomeController @Inject()(val controllerComponents: ControllerComponents) extends BaseController with I18nSupport{

  val postPost = PostModel.post
  val imageImage = ImageModel.image
  val commentComent = CommentModel.comments
  // val tempImages = TempImageModel.tempList

  def postForms = Form{
    mapping(
      "id" -> default(uuid, UUID.randomUUID()),
      "Post: " -> nonEmptyText,
      "Password: " -> optional(text),
      "images" -> list(imageForm.mapping),
      "comments" -> list(commentForm.mapping),
    )(PostModel.apply)(PostModel.unapply)
  }

  def imageForm = Form {
    mapping(
      "id" -> default(uuid, UUID.randomUUID()),
      "imageName" -> ignored(""),
    )(ImageModel.apply)(ImageModel.unapply)
  }

  def commentForm = Form {
    mapping(
      "id" -> default(uuid, UUID.randomUUID()),
      "comments" -> text
    )(CommentModel.apply)(CommentModel.unapply)
  }



  def index() = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.index(postForms, postPost.toList, imageForm, imageImage.toList))
  }

  def addPost() = Action(parse.multipartFormData) { implicit request =>
    postForms.bindFromRequest().fold(
      formWithErrors => {
        BadRequest("Something went wrong.")
      },
      postM => {
        request.body
        .file("picture")
        .map { picture => 
          val filename    = Paths.get(picture.filename).getFileName
          val fileSize    = picture.fileSize
          val contentType = picture.contentType 

          picture.ref.copyTo(Paths.get(s"public/images/$filename"), replace = true)
          val x = ImageModel.addImage(ImageModel(UUID.randomUUID(), s"/images/$filename"))
          PostModel.addPosts(PostModel(postM.id, postM.postMessage, postM.postPassword, x.toList, commentComent.toList))
          Redirect(routes.HomeController.index())
        }
        .getOrElse {
          Redirect(routes.HomeController.index()).flashing("error" -> "Missing file")
        }
      
      }
    )
  }

  def deletePost(id: UUID) = Action {implicit request =>
    postForms.bindFromRequest().fold(
      formWithErrors => {
        BadRequest("Something went uuuuuhhhh... hehehehe")
      },
      del => {
        PostModel.deletePost(del.id, del.postPassword)
        Redirect(routes.HomeController.index())
      }
    )

  }


  def addComment(id: UUID) = Action { implicit request => 
   commentForm.bindFromRequest().fold(
    formWithErrors => {
      BadRequest("Something went uuuuuhhhh...")
    },
    comm => {
      CommentModel.addNewComment(CommentModel(comm.id, comm.comment))
      Redirect(routes.HomeController.index())
    }
   ) 
  }


}
