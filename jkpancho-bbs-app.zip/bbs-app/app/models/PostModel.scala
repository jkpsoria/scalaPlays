package models

import scala.collection.mutable.ListBuffer
import java.util.UUID
import java.awt.Image


case class PostModel(id: UUID, postMessage: String, postPassword: Option[String], postImages: List[ImageModel], comments: List[CommentModel])

object PostModel {
    val post: ListBuffer[PostModel] = ListBuffer()

    def addPosts(newPost: PostModel) = post += newPost


    def findByID(id: UUID): Option[PostModel] = post.find(_.id == id)

    def deletePost(ids: UUID, password: Option[String]) = {
        findByID(ids) match {
            case Some(posts) => {
                if(posts.postPassword == Some(password)){
                    post -= posts
                    true
                }
                else{
                    false
                }
            }
            case None => false
        }
    }
}

case class ImageModel(id: UUID, imageName: String)

object ImageModel{
    val image: ListBuffer[ImageModel] = ListBuffer()

    def addImage(newImage: ImageModel) = {
        image.clear()
        image += newImage
    }
}

case class CommentModel(id: UUID, comment: String)

object CommentModel{
    val comments: ListBuffer[CommentModel] = ListBuffer()

    def addNewComment(newComment: CommentModel) = comments += newComment
}

// case class TempImageModel(id: UUID, tempImage: String)

// object TempImageModel{
//     val tempList: ListBuffer[TempImageModel] = ListBuffer()

//     def uploadImage(tempImage: TempImageModel) = tempList += tempImage
// }