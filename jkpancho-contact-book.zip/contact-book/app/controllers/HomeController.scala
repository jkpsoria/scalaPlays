package controllers

import javax.inject._
import play.api._
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import models._
import play.api.i18n._
import java.util.UUID


@Singleton
class HomeController @Inject()(val controllerComponents: ControllerComponents) extends BaseController with I18nSupport {

  val contactData = ContactModel
  val contactInfoDetails = ContactModel.contactInfo

  def contactInfoForm = Form(
    mapping(
      "id" -> default(uuid, UUID.randomUUID()),
      "name" -> nonEmptyText,
      "phoneNum"  -> number,
      "email" -> email
    )(contactData.apply)(contactData.unapply)
  )

  def contact() = Action { implicit request: Request[AnyContent] =>
    Ok(views.html.contact(contactInfoForm, contactInfoDetails.toList))
  }

  def addContact() = Action { implicit request => 
    contactInfoForm.bindFromRequest().fold(
      formWithErrors => {
        BadRequest("Something went wrong!")
      },
      contact => {
        contactData.add(contact)
        Ok(views.html.contact(contactInfoForm, contactInfoDetails.toList))
      }
    )  
  }

  // def deleteContact(id: Int) = Action { implicit request => 
  //   contactInfoForm.bindFromRequest().fold(
  //     formWithErrors => {
  //       BadRequest("Something went wrong!")
  //     },
  //     contactDelete => {
  //       contactData.delete(id)
  //       Redirect(routes.HomeController.deleteContact(id))
  //     }
  //   )  
  // }

  def deleteContact(id: UUID) = Action {
    contactData.delete(id)
      Redirect(routes.HomeController.contact())
    
  }

  def updateContactForm(id: UUID) = Action { implicit request =>
    Ok

  }
}
