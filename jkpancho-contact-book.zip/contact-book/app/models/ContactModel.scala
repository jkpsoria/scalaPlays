package models

import scala.collection.mutable.ListBuffer
import java.util.UUID

case class ContactModel(id: UUID, name: String, phoneNum: Int, email: String)



object ContactModel{

    val contact1 = ContactModel(UUID.randomUUID(), "jiki", 123, "jk@gmail.com")

    val contactInfo: ListBuffer[ContactModel] = ListBuffer(contact1)


    def add(contactDetails: ContactModel) = contactInfo += contactDetails

    def delete(id: UUID) = {
        val indexed = contactInfo.indexWhere(_.id == id)
        contactInfo.remove(indexed)
    }

    def updateC(data: ContactModel) = {
        val indexed = contactInfo.indexWhere(_.id == data.id)
        contactInfo.update(indexed, data)
    }

}


